# The SAGE Framework

**Closed-form analytical bounds for quantum repeater network optimization.**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![arXiv](https://img.shields.io/badge/arXiv-pending-b31b1b.svg)](#)

---

## What This Does

The SAGE Framework provides **O(1) feasibility testing** for quantum repeater networks directly from hardware datasheets. No simulation required.

Given a hardware platform's gate fidelity, coherence time, and entanglement generation probability, the Sage Bound tells you:

- **Maximum achievable end-to-end fidelity** at any distance
- **Minimum node count** to reach the BB84 security threshold
- **The Sage Wall** — the hard distance limit for your hardware, regardless of how many nodes you deploy
- **Sensitivity analysis** — which hardware improvement gives you the most bang for the buck
- **Stochastic penalty** — how much realistic probabilistic generation hurts you: (1 + 2/p)

## Key Results

| Distance | Willow N* | Willow F_best | QuEra N* | QuEra F_best |
|----------|-----------|---------------|----------|--------------|
| 500 km   | 7         | 0.859         | —        | —            |
| 1,000 km | 12        | 0.854         | —        | —            |
| 2,000 km | 22        | 0.851         | —        | —            |
| 4,000 km | —         | infeasible    | —        | —            |
| 8,200 km | —         | infeasible    | —        | —            |

**No existing hardware achieves intercontinental QKD.** The Sage Bound quantifies exactly what improvements are needed.

## Quick Start

```bash
pip install numpy
python -m core.sage_bound
```

### As a Library

```python
from core import WILLOW, analyze_feasibility

# Is 1000 km feasible with Google Willow hardware?
result = analyze_feasibility(WILLOW, L_km=1000)
print(f"Feasible: {result.feasible}")        # True
print(f"Min nodes: {result.min_N}")           # 12
print(f"Sage Wall: {result.sage_wall_km} km") # ~2000 km
print(f"Penalty: {result.penalty_factor}×")   # 21.0×

# Custom hardware
from core import HardwareSpec
my_hw = HardwareSpec("NextGen", f_gate=0.999, t2=500e-6, p_gen=0.30)
result = analyze_feasibility(my_hw, L_km=4000)
```

### Monte Carlo Validation

```python
from core import validate_bound, WILLOW

v = validate_bound(WILLOW, L_km=500, N=10, trials=10_000)
print(f"Sage Bound: {v['F_stoch']:.4f}")
print(f"MC Mean:    {v['F_mc_mean']:.4f} ± {v['F_mc_std']:.4f}")
print(f"Conservative: {v['agreement']}")  # True — bound <= MC mean
```

## The Mathematics

### The Log-Map

Fidelity degrades multiplicatively through a repeater chain:

$$F_{\text{total}} = \prod_{i=1}^{N} F_i$$

The logarithmic map φ: (ℝ⁺, ×) → (ℝ, +) transforms this into a linear program:

$$\log(F_{\text{total}}) = \sum_{i=1}^{N} \alpha_i$$

This is exact, not an approximation.

### The Stochastic Penalty

Probabilistic entanglement generation (success probability p) amplifies decoherence by:

$$(1 + 2/p)$$

At p = 0.10 (Willow), this is a **21× penalty**. Derived from the geometric retry distribution via Jensen's inequality. Provably conservative.

### Universal Sensitivity

$$\frac{\partial \log F_{\text{total}}}{\partial \log F_{\text{gate},j}} = 2$$

Improving gate fidelity by δ at *any* node improves total log-fidelity by exactly 2δ. Independent of N, L, or topology.

## Repository Structure

```
sage-framework/
├── core/                    # The Sage Bound — theorems + validation
│   ├── sage_bound.py        # All four theorems, feasibility analysis, MC validation
│   └── __init__.py
├── validation/              # Independent validation scripts
│   └── qutip_validation.py  # QuTiP density matrix comparison
├── calculator/              # Web-based interactive calculator
│   └── sage_calculator.jsx  # React component
├── demos/                   # Educational demonstrations
│   ├── quantum_dice.py
│   ├── entanglement.py
│   └── teleportation.py
├── exploration/             # Research exploration (philosophical origins)
│   └── singularity_protocol.py
├── docs/                    # Paper drafts and documentation
├── data/                    # Validation data and results
├── requirements.txt
├── LICENSE
└── README.md
```

## Validation

The Sage Bound is validated against four independent methods:

| Method | Fidelity | Gap from MC |
|--------|----------|-------------|
| Deterministic bound | 0.857 | +3.9% |
| QuTiP density matrix | 0.841 | +2.0% |
| Monte Carlo (10⁴ trials) | 0.825 | reference |
| **Stochastic bound (Sage)** | **0.818** | **−0.8%** |

The strict ordering F_stoch ≤ F_MC ≤ F_QuTiP ≤ F_det holds across all tested configurations.

## Origin Story

This framework emerged from a philosophical question: *Does identity persist through quantum teleportation?* That question was translated — via AI-assisted exploration — into concrete engineering: optimizing fidelity in noisy repeater chains. The philosophical origin is documented in [`exploration/`](exploration/) and in the methodology paper. The core theorems stand independently of the philosophical framing.

**Full transparency:** This research was conducted with AI assistance (Claude, Gemini) for mathematical exploration and rapid prototyping. All analytical results were independently validated through Monte Carlo simulation and QuTiP density-matrix computation.

## Citation

```bibtex
@article{flett2026sage,
  author  = {Flett, Tylor},
  title   = {The Sage Bound: Optimal Quantum Network Reach Under
             Heterogeneous Hardware and Stochastic Entanglement Generation},
  year    = {2026},
  note    = {arXiv: pending}
}
```

## License

MIT — See [LICENSE](LICENSE)

## Contact

- **Author:** Tylor Flett
- **Email:** innerpeacesage@gmail.com
- **ORCID:** 0009-0008-5448-0405

---

*The bottleneck in quantum networking isn't simulation speed — it's knowing what to simulate. The Sage Bound answers feasibility before you write the first line of simulation code.*
