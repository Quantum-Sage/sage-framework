"""
SAGE Framework — Core Module

Closed-form analytical bounds for quantum repeater network optimization.
"""

from .sage_bound import (
    HardwareSpec,
    WILLOW,
    QUERA,
    BB84_THRESHOLD,
    C_FIBER,
    sage_bound_deterministic,
    sage_bound_stochastic,
    stochastic_penalty,
    purification_ceiling,
    analyze_feasibility,
    find_sage_wall,
    sensitivity_gate,
    required_improvement,
    monte_carlo_fidelity,
    validate_bound,
)

__all__ = [
    "HardwareSpec",
    "WILLOW",
    "QUERA",
    "BB84_THRESHOLD",
    "C_FIBER",
    "sage_bound_deterministic",
    "sage_bound_stochastic",
    "stochastic_penalty",
    "purification_ceiling",
    "analyze_feasibility",
    "find_sage_wall",
    "sensitivity_gate",
    "required_improvement",
    "monte_carlo_fidelity",
    "validate_bound",
]
