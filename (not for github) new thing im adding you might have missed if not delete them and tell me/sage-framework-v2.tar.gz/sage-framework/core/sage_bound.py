"""
sage_bound.py — Core implementation of the Sage Bound theorems.

Provides closed-form analytical bounds for quantum repeater network
feasibility. No simulation required — O(1) from hardware datasheets.

Reference: Flett (2026), "The Sage Bound: Optimal Quantum Network Reach
Under Heterogeneous Hardware and Stochastic Entanglement Generation"

Theorems implemented:
    1. Sage Bound (Thm 1) — Max achievable end-to-end fidelity
    2. Spacing Independence (Thm 2) — N* independent of spacing distribution
    3. Stochastic Sage Bound (Thm 3) — Conservative floor under probabilistic generation
    4. Purification Ceiling (Thm 4) — Upper limit on purification improvement
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Dict

# ═══════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════

C_FIBER = 2e5          # Speed of light in fiber (km/s)
BB84_THRESHOLD = 0.851  # Shor-Preskill security bound (QBER ~11%)


# ═══════════════════════════════════════════════════════════════
# Hardware Dataclass
# ═══════════════════════════════════════════════════════════════

@dataclass
class HardwareSpec:
    """Quantum repeater hardware specification.

    Attributes:
        name: Human-readable identifier
        f_gate: Two-qubit gate fidelity (dimensionless, 0 < f_gate <= 1)
        t2: Coherence time in seconds
        p_gen: Entanglement generation probability per attempt (0 < p_gen <= 1)
    """
    name: str
    f_gate: float
    t2: float       # seconds
    p_gen: float

    def __post_init__(self):
        assert 0 < self.f_gate <= 1, f"f_gate must be in (0, 1], got {self.f_gate}"
        assert self.t2 > 0, f"t2 must be positive, got {self.t2}"
        assert 0 < self.p_gen <= 1, f"p_gen must be in (0, 1], got {self.p_gen}"


# Reference hardware platforms
# Note: T2 here is the MEMORY coherence time at repeater nodes, not
# the raw qubit T2 of the gate hardware. For network operations,
# quantum memories (NV centers, trapped ions, rare-earth) provide
# the relevant coherence timescale during entanglement generation.
#
# Willow-class: superconducting gates (F_gate=0.997) paired with
#   quantum memory of ~1s coherence (e.g., microwave-optical transducer)
# QuEra-class: neutral atom gates (F_gate=0.995) with inherent
#   ~10s memory coherence via optical trapping
WILLOW = HardwareSpec("Google Willow", f_gate=0.997, t2=1.0, p_gen=0.10)
QUERA = HardwareSpec("QuEra", f_gate=0.995, t2=10.0, p_gen=0.05)


# ═══════════════════════════════════════════════════════════════
# Theorem 1: Sage Bound
# ═══════════════════════════════════════════════════════════════

def log_fidelity_deterministic(hw: HardwareSpec, spacing_km: float) -> float:
    """Per-hop log-fidelity under deterministic (perfect generation) conditions.

    α_h(s) = 2·log(F_gate) - s/(c·T₂)

    Args:
        hw: Hardware specification
        spacing_km: Segment length in km

    Returns:
        Log-fidelity α (negative number; more negative = worse)
    """
    t_link = spacing_km / C_FIBER
    return 2 * np.log(hw.f_gate) - t_link / hw.t2


def sage_bound_deterministic(hw: HardwareSpec, L_km: float, N: int) -> float:
    """Theorem 1: Maximum achievable end-to-end fidelity (deterministic).

    F_max = exp(N · α_h(L/N))

    Args:
        hw: Hardware specification
        L_km: Total network distance in km
        N: Number of repeater nodes

    Returns:
        End-to-end fidelity F_total
    """
    s = L_km / N
    alpha = log_fidelity_deterministic(hw, s)
    return np.exp(N * alpha)


# ═══════════════════════════════════════════════════════════════
# Theorem 3: Stochastic Sage Bound
# ═══════════════════════════════════════════════════════════════

def stochastic_penalty(p_gen: float) -> float:
    """The (1 + 2/p) decoherence amplification factor.

    Derived from geometric retry distribution via Jensen's inequality.
    This is provably conservative: true expected fidelity >= bound.

    Args:
        p_gen: Entanglement generation probability

    Returns:
        Multiplicative penalty factor (always >= 3)
    """
    return 1.0 + 2.0 / p_gen


def log_fidelity_stochastic(hw: HardwareSpec, spacing_km: float) -> float:
    """Per-hop log-fidelity under stochastic entanglement generation.

    α_h^stoch(s) = 2·log(F_gate) - (s/(c·T₂)) · (1 + 2/p)

    This is the conservative floor from Theorem 3.

    Args:
        hw: Hardware specification
        spacing_km: Segment length in km

    Returns:
        Stochastic log-fidelity (more negative than deterministic)
    """
    t_link = spacing_km / C_FIBER
    penalty = stochastic_penalty(hw.p_gen)
    return 2 * np.log(hw.f_gate) - (t_link / hw.t2) * penalty


def sage_bound_stochastic(hw: HardwareSpec, L_km: float, N: int) -> float:
    """Theorem 3: Conservative fidelity bound under probabilistic generation.

    Args:
        hw: Hardware specification
        L_km: Total network distance in km
        N: Number of repeater nodes

    Returns:
        Conservative lower bound on expected end-to-end fidelity
    """
    s = L_km / N
    alpha = log_fidelity_stochastic(hw, s)
    return np.exp(N * alpha)


# ═══════════════════════════════════════════════════════════════
# Theorem 4: Purification Ceiling
# ═══════════════════════════════════════════════════════════════

def purification_ceiling(F: float) -> float:
    """Theorem 4: Maximum fidelity improvement from single-round DEJMPS purification.

    ΔF_purify <= F²/(F² + (1-F)²) - F

    Args:
        F: Input per-hop fidelity

    Returns:
        Maximum achievable improvement ΔF
    """
    F_prime = F**2 / (F**2 + (1 - F)**2)
    return F_prime - F


# ═══════════════════════════════════════════════════════════════
# Feasibility Analysis
# ═══════════════════════════════════════════════════════════════

@dataclass
class FeasibilityResult:
    """Complete feasibility analysis for a hardware + distance combination."""
    hw: HardwareSpec
    L_km: float
    threshold: float
    feasible: bool
    min_N: Optional[int]          # Minimum nodes achieving threshold (None if infeasible)
    best_fidelity: float          # Peak achievable fidelity at optimal N
    best_N: int                   # Node count achieving peak fidelity
    sage_wall_km: float           # Maximum distance for this hardware
    penalty_factor: float         # (1 + 2/p)
    gate_budget: float            # Total gate error contribution at best_N
    deco_budget: float            # Total decoherence contribution at best_N
    spacing_km: float             # Optimal spacing at best_N
    f_hop_stochastic: float       # Per-hop stochastic fidelity at best_N


def analyze_feasibility(
    hw: HardwareSpec,
    L_km: float,
    threshold: float = BB84_THRESHOLD,
    max_N: int = 500,
) -> FeasibilityResult:
    """Complete Sage Bound feasibility analysis.

    Finds the optimal node count, checks threshold feasibility,
    and computes the error budget decomposition.

    Args:
        hw: Hardware specification
        L_km: Target distance in km
        threshold: Fidelity threshold (default: BB84 = 0.851)
        max_N: Maximum nodes to search

    Returns:
        FeasibilityResult with complete analysis
    """
    best_f = 0.0
    best_n = 1
    min_n = None

    for n in range(1, max_N + 1):
        f = sage_bound_stochastic(hw, L_km, n)
        if f > best_f:
            best_f = f
            best_n = n
        if f >= threshold and min_n is None:
            min_n = n
        # Early termination: well past the peak
        if n > 10 and f < best_f * 0.3:
            break

    # Error budget at optimal N
    use_n = min_n if min_n else best_n
    s = L_km / use_n
    gate_budget = 2 * use_n * np.log(hw.f_gate)
    t_link = s / C_FIBER
    deco_budget = -use_n * (t_link / hw.t2) * stochastic_penalty(hw.p_gen)
    f_hop = np.exp(log_fidelity_stochastic(hw, s))

    # Sage Wall
    wall = find_sage_wall(hw, threshold)

    return FeasibilityResult(
        hw=hw,
        L_km=L_km,
        threshold=threshold,
        feasible=min_n is not None,
        min_N=min_n,
        best_fidelity=best_f,
        best_N=best_n,
        sage_wall_km=wall,
        penalty_factor=stochastic_penalty(hw.p_gen),
        gate_budget=gate_budget,
        deco_budget=deco_budget,
        spacing_km=s,
        f_hop_stochastic=f_hop,
    )


def find_sage_wall(
    hw: HardwareSpec,
    threshold: float = BB84_THRESHOLD,
    step_km: float = 100,
    max_km: float = 50000,
) -> float:
    """Find the Sage Wall: maximum distance where threshold is achievable.

    Args:
        hw: Hardware specification
        threshold: Fidelity threshold
        step_km: Distance search step
        max_km: Maximum search distance

    Returns:
        Maximum feasible distance in km
    """
    last_feasible = 0
    for L in np.arange(step_km, max_km + step_km, step_km):
        # Quick check: find best fidelity at this distance
        best_f = 0
        for n in range(1, 500):
            f = sage_bound_stochastic(hw, L, n)
            if f > best_f:
                best_f = f
            elif n > 5 and f < best_f * 0.3:
                break
        if best_f >= threshold:
            last_feasible = L
        elif last_feasible > 0:
            # We've passed the wall
            break
    return last_feasible


# ═══════════════════════════════════════════════════════════════
# Sensitivity Analysis (Corollary)
# ═══════════════════════════════════════════════════════════════

def sensitivity_gate() -> float:
    """Universal gate fidelity sensitivity.

    ∂ log(F_total) / ∂ log(F_gate,j) = 2 for all j.

    This is independent of N, L, spacing, or topology.
    Improving F_gate by fraction δ at any node improves
    log(F_total) by exactly 2δ.

    Returns:
        Sensitivity coefficient (always exactly 2)
    """
    return 2.0


def required_improvement(
    hw: HardwareSpec,
    L_km: float,
    threshold: float = BB84_THRESHOLD,
) -> Dict[str, Optional[float]]:
    """Compute the minimum single-parameter improvements needed for feasibility.

    For each of (f_gate, t2, p_gen), finds the smallest value that makes
    the target distance feasible while holding other parameters fixed.

    Args:
        hw: Current hardware specification
        L_km: Target distance
        threshold: Fidelity threshold

    Returns:
        Dict with keys 'f_gate', 't2', 'p_gen' mapping to required values
        (or None if no single-parameter improvement suffices)
    """
    results = {}

    # f_gate sweep
    needed = None
    for f in np.arange(hw.f_gate, 1.0, 0.0001):
        test_hw = HardwareSpec(hw.name, f, hw.t2, hw.p_gen)
        res = analyze_feasibility(test_hw, L_km, threshold)
        if res.feasible:
            needed = f
            break
    results['f_gate'] = needed

    # p_gen sweep
    needed = None
    for p in np.arange(hw.p_gen, 1.01, 0.01):
        if p > 1.0:
            break
        test_hw = HardwareSpec(hw.name, hw.f_gate, hw.t2, min(p, 1.0))
        res = analyze_feasibility(test_hw, L_km, threshold)
        if res.feasible:
            needed = p
            break
    results['p_gen'] = needed

    # t2 sweep (in seconds)
    needed = None
    for t2_factor in np.arange(1.0, 1000.0, 0.5):
        test_hw = HardwareSpec(hw.name, hw.f_gate, hw.t2 * t2_factor, hw.p_gen)
        res = analyze_feasibility(test_hw, L_km, threshold)
        if res.feasible:
            needed = hw.t2 * t2_factor
            break
    results['t2'] = needed

    return results


# ═══════════════════════════════════════════════════════════════
# Monte Carlo Validation
# ═══════════════════════════════════════════════════════════════

def monte_carlo_fidelity(
    hw: HardwareSpec,
    L_km: float,
    N: int,
    trials: int = 10000,
    seed: Optional[int] = None,
) -> Tuple[float, float]:
    """Monte Carlo validation of the stochastic bound.

    Simulates the geometric retry process and decoherence explicitly.
    The Sage Bound should be <= MC mean (conservative floor).

    Args:
        hw: Hardware specification
        L_km: Total distance
        N: Number of nodes
        trials: Number of MC trials
        seed: Random seed for reproducibility

    Returns:
        Tuple of (mean_fidelity, std_fidelity) across trials
    """
    rng = np.random.default_rng(seed)
    s = L_km / N
    tau = 2 * s / C_FIBER  # round-trip time per retry

    fidelities = np.zeros(trials)

    for trial in range(trials):
        log_f = 0.0
        for _ in range(N):
            # Gate error (deterministic)
            log_f += 2 * np.log(hw.f_gate)

            # Geometric retries
            attempts = rng.geometric(hw.p_gen)
            t_wait = s / C_FIBER + (attempts - 1) * tau  # link time + retry time

            # Decoherence during wait
            log_f -= t_wait / hw.t2

        fidelities[trial] = np.exp(log_f)

    return float(np.mean(fidelities)), float(np.std(fidelities))


def validate_bound(
    hw: HardwareSpec,
    L_km: float,
    N: int,
    trials: int = 10000,
    seed: int = 42,
) -> Dict:
    """Validate that Sage Bound <= MC mean (conservative property).

    Args:
        hw: Hardware specification
        L_km: Distance
        N: Node count
        trials: MC trials
        seed: Random seed

    Returns:
        Dict with bound, MC results, and agreement flag
    """
    f_det = sage_bound_deterministic(hw, L_km, N)
    f_stoch = sage_bound_stochastic(hw, L_km, N)
    mc_mean, mc_std = monte_carlo_fidelity(hw, L_km, N, trials, seed)

    # The ordering should be: F_stoch <= F_mc <= F_det
    agreement = f_stoch <= mc_mean + 2 * mc_std  # within 2σ

    return {
        "N": N,
        "L_km": L_km,
        "F_det": f_det,
        "F_stoch": f_stoch,
        "F_mc_mean": mc_mean,
        "F_mc_std": mc_std,
        "agreement": agreement,
        "gap_pct": (mc_mean - f_stoch) / mc_mean * 100 if mc_mean > 0 else 0,
    }


# ═══════════════════════════════════════════════════════════════
# CLI entry point
# ═══════════════════════════════════════════════════════════════

def main():
    """Quick demonstration of the Sage Bound analysis."""
    print("=" * 64)
    print("  THE SAGE BOUND — Quantum Network Feasibility Calculator")
    print("  Flett (2026)")
    print("=" * 64)

    for hw in [WILLOW, QUERA]:
        print(f"\n{'─' * 64}")
        print(f"  Hardware: {hw.name}")
        print(f"  F_gate = {hw.f_gate} | T₂ = {hw.t2:.2g} s | p_gen = {hw.p_gen}")
        print(f"  Stochastic penalty: (1 + 2/p) = {stochastic_penalty(hw.p_gen):.1f}×")
        print(f"{'─' * 64}")

        for L in [500, 1000, 2000, 4000, 8200]:
            result = analyze_feasibility(hw, L)
            status = f"N* = {result.min_N}" if result.feasible else "INFEASIBLE"
            print(f"  L = {L:>5,} km  |  {status:>14s}  |  F_best = {result.best_fidelity:.4f} (N={result.best_N})")

        print(f"\n  Sage Wall: {find_sage_wall(hw):,.0f} km")

    # Validation
    print(f"\n{'═' * 64}")
    print("  VALIDATION: Sage Bound vs Monte Carlo (10⁴ trials)")
    print(f"{'═' * 64}")
    for N in [5, 10, 15, 20]:
        v = validate_bound(WILLOW, 500, N)
        mark = "✓" if v["agreement"] else "✗"
        print(f"  N={N:3d}  F_stoch={v['F_stoch']:.4f}  F_mc={v['F_mc_mean']:.4f}±{v['F_mc_std']:.4f}  gap={v['gap_pct']:+.1f}%  [{mark}]")

    print()


if __name__ == "__main__":
    main()
