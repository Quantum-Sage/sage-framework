"""
qutip_validation.py — Independent validation of the Sage Bound via QuTiP.

Simulates the quantum repeater chain using explicit density matrix evolution
and compares against the analytical Sage Bound. Validates the ordering:

    F_stoch <= F_MC <= F_QuTiP <= F_det

Requires: pip install qutip numpy matplotlib

Reference: Flett (2026), "The Sage Bound"
"""

import numpy as np

try:
    import qutip as qt
    HAS_QUTIP = True
except ImportError:
    HAS_QUTIP = False
    print("QuTiP not installed. Run: pip install qutip")
    print("Falling back to analytical-only validation.\n")

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.sage_bound import (
    HardwareSpec, WILLOW, QUERA, C_FIBER,
    sage_bound_deterministic, sage_bound_stochastic,
    monte_carlo_fidelity,
)


def qutip_simulation(hw: HardwareSpec, L_km: float, N: int) -> float:
    """Simulate the repeater chain using QuTiP density matrices.

    Models depolarizing gate noise and dephasing decoherence on a
    two-qubit Bell state through N repeater hops.

    Args:
        hw: Hardware specification
        L_km: Total distance
        N: Number of nodes

    Returns:
        End-to-end fidelity from density matrix simulation
    """
    if not HAS_QUTIP:
        return None

    s = L_km / N
    t_wait = s / C_FIBER

    # Initial state: |Φ+⟩ Bell state
    psi0 = qt.bell_state('00')
    rho = qt.ket2dm(psi0)

    # Dephasing rate from coherence time
    gamma = 1 - np.exp(-t_wait / hw.t2)

    for _ in range(N):
        # 1. Depolarizing gate noise
        rho = (hw.f_gate**2) * rho + ((1 - hw.f_gate**2) / 4) * qt.qeye([2, 2])

        # 2. Phase damping (decoherence during wait)
        rho = qt.phase_damping(gamma, gamma)(rho)

    # Fidelity with initial Bell state
    final_fidelity = qt.fidelity(rho, qt.ket2dm(psi0))**2
    return float(final_fidelity)


def full_validation(
    hw: HardwareSpec,
    L_km: float,
    N_range: list,
    mc_trials: int = 10000,
    seed: int = 42,
) -> dict:
    """Run complete four-level validation hierarchy.

    Computes F_det, F_QuTiP, F_MC, F_stoch for each N and checks ordering.

    Args:
        hw: Hardware specification
        L_km: Total distance
        N_range: List of node counts to test
        mc_trials: Monte Carlo trials per N
        seed: Random seed

    Returns:
        Dict with results and validation status
    """
    results = []

    for N in N_range:
        f_det = sage_bound_deterministic(hw, L_km, N)
        f_stoch = sage_bound_stochastic(hw, L_km, N)
        f_mc, f_mc_std = monte_carlo_fidelity(hw, L_km, N, mc_trials, seed)
        f_qutip = qutip_simulation(hw, L_km, N) if HAS_QUTIP else None

        # Check ordering: F_stoch <= F_MC <= F_QuTiP <= F_det
        if f_qutip is not None:
            ordering_ok = (f_stoch <= f_mc + 2*f_mc_std) and (f_mc <= f_qutip * 1.05) and (f_qutip <= f_det * 1.01)
        else:
            ordering_ok = (f_stoch <= f_mc + 2*f_mc_std)

        results.append({
            "N": N,
            "F_det": f_det,
            "F_qutip": f_qutip,
            "F_mc": f_mc,
            "F_mc_std": f_mc_std,
            "F_stoch": f_stoch,
            "ordering_ok": ordering_ok,
        })

    all_ok = all(r["ordering_ok"] for r in results)

    return {
        "hw": hw.name,
        "L_km": L_km,
        "results": results,
        "all_ordering_valid": all_ok,
    }


def print_validation(val: dict):
    """Pretty-print validation results."""
    print(f"\n{'═' * 72}")
    print(f"  VALIDATION: {val['hw']} at {val['L_km']} km")
    print(f"{'═' * 72}")

    header = f"  {'N':>3s}  {'F_det':>8s}  {'F_QuTiP':>8s}  {'F_MC':>8s}  {'F_stoch':>8s}  {'gap%':>6s}  {'ok':>3s}"
    print(header)
    print("  " + "─" * 66)

    for r in val["results"]:
        qutip_str = f"{r['F_qutip']:.4f}" if r["F_qutip"] is not None else "  N/A "
        gap = (r["F_mc"] - r["F_stoch"]) / r["F_mc"] * 100 if r["F_mc"] > 0.001 else 0
        mark = " ✓ " if r["ordering_ok"] else " ✗ "
        print(f"  {r['N']:3d}  {r['F_det']:8.4f}  {qutip_str}  {r['F_mc']:8.4f}  {r['F_stoch']:8.4f}  {gap:+5.1f}%  {mark}")

    status = "ALL PASS" if val["all_ordering_valid"] else "SOME FAILURES"
    print(f"\n  Ordering F_stoch ≤ F_MC ≤ F_QuTiP ≤ F_det: {status}")


def main():
    """Run validation suite."""
    print("THE SAGE BOUND — Validation Suite")
    print("=" * 72)

    # Willow at 500km
    v1 = full_validation(WILLOW, L_km=500, N_range=[1, 3, 5, 8, 10, 15, 20])
    print_validation(v1)

    # QuEra at 1000km
    v2 = full_validation(QUERA, L_km=1000, N_range=[1, 3, 5, 8, 10])
    print_validation(v2)

    # Willow at 2000km (should show the Sage Wall)
    v3 = full_validation(WILLOW, L_km=2000, N_range=[1, 5, 10, 20, 30, 40])
    print_validation(v3)

    print(f"\n{'═' * 72}")
    all_pass = v1["all_ordering_valid"] and v2["all_ordering_valid"] and v3["all_ordering_valid"]
    print(f"  OVERALL: {'ALL VALIDATIONS PASS ✓' if all_pass else 'SOME VALIDATIONS FAILED ✗'}")
    print(f"{'═' * 72}\n")


if __name__ == "__main__":
    main()
